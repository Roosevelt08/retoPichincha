package com.demo.retoPichincha;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetoPichinchaApplicationTests {

	@Test
	void contextLoads() {
	}

}
